package restaurante;

import Vista.FrmLogin;

public class Restaurante {

    public static void main(String[] args) {
        FrmLogin iniciar = new FrmLogin();
        iniciar.setVisible(true);
    }
    
}
